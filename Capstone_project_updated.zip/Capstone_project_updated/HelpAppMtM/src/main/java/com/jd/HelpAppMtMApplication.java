package com.jd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelpAppMtMApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelpAppMtMApplication.class, args);
	}

}
