package com.jd.service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jd.data.HelpRepository;
import com.jd.data.KeywordRepository;
import com.jd.model.Keyword;
import com.jd.model.KnowledgeBase;

@Service
public class HelpService {

	@Autowired
	private HelpRepository repo;
	@Autowired
	private KeywordRepository krepo;

	public List<KnowledgeBase> getAllContents() {
		List<KnowledgeBase> kbs = repo.findAll();
		for(KnowledgeBase kb : kbs) {
			kb.getKeywords().clear();
		}
		
		return kbs;
	}

	public Set<KnowledgeBase> getSearchResult(String searchText) {
		// Split search text into array of keywords
		String[] strArr = searchText.split(" ");
		Set<KnowledgeBase> result = new HashSet<KnowledgeBase>();

		repo.findAll().forEach(content -> {
			content.getKeywords().forEach(keyword -> {
				for (String str : strArr)
					if (str.toLowerCase() == keyword.getKeyword().toLowerCase()) {
						result.add(content);
						break;
					}
			});
		});
		return result;
	}

	public KnowledgeBase addNewContent(KnowledgeBase kb) {
		// Search for already existing keywords before adding new content
		
		Set<Keyword> keys = kb.getKeywords();
  
		for(Keyword key : keys) {
			String strKey = key.getKeyword().toLowerCase();
			key.setKeyword(strKey);
			Keyword k = krepo.findByKeyword(strKey);
			if( k != null) {
				kb.getKeywords().remove(key);
				kb.getKeywords().add(k);
			}
		}
		kb = repo.save(kb);
		kb.getKeywords().clear();
		return kb;
	}

	public KnowledgeBase deleteExistingContent(int id) {
		Optional<KnowledgeBase> okb = repo.findById(id);
		KnowledgeBase kb = okb.orElse(null);
		if (kb != null)
			repo.deleteById(id);
		return kb;
	}

}
