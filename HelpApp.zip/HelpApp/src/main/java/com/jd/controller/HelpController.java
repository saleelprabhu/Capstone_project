package com.jd.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jd.model.KnowledgeBase;
import com.jd.service.HelpService;

@RequestMapping(path = "/webapp")
@EnableJpaRepositories(basePackages = "com.jd.data")
@CrossOrigin
@RestController
public class HelpController {
	
	@Autowired
	private HelpService service;

	private HelpController() {
		System.out.println("HelpController - Default Constructor");
	}
	
	@GetMapping(path = "/contents")
	public Set<KnowledgeBase> getSearchDetails(@RequestParam String searchString) {
		return service.getSearchResult(searchString);
	}
	
	@GetMapping(path = "/allcontents")
	public List<KnowledgeBase> getAll() {
		return service.getAllContents();
	}
	
	@PostMapping(path = "/contents")
	public KnowledgeBase addContent(@RequestBody KnowledgeBase kb) {
		return service.addNewContent(kb);
	}
	
	@DeleteMapping(path = "/contents/{id}")
	public KnowledgeBase deleteContent(@PathVariable int id) {
		return service.deleteExistingContent(id);
	}
}