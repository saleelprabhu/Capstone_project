package com.jd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelpAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
